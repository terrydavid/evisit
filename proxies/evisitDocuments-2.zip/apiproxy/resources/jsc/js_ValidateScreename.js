var screenName = context.getVariable("request.queryparam.screenName");
var username = context.getVariable("accesstoken.username");

if (screenName !== null)
{
    context.setVariable("my.error","false");
    
    if (username !== screenName.toLowerCase())
    {
      context.setVariable("my.error","true");
    }
}