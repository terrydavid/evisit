var clientid = context.getVariable("request.queryparam.client_id");
var clientsecret = context.getVariable("request.queryparam.client_secret");

context.setVariable("request.header.TH-ClientID", clientid);
context.setVariable("request.header.TH-ClientSecret", clientsecret);

// var apigeetoken = context.getVariable("apigee.access_token");
// context.setVariable("niq.redirect_uri", "https://th-innovation-dev.apigee.net/nidp/redir?client_id="+clientid+"&client_secret="+clientsecret);
// context.setVariable("niq.redirect_uri", "https://th-innovation-dev.apigee.net/nidp/redir?aat="+apigeetoken);