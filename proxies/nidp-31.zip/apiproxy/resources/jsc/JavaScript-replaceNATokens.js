var respayld = context.getVariable ("response.content");
var rpl = JSON.parse(respayld);
var Aat = context.getVariable("oauthv2accesstoken.Set-OAuth-v20-Info-NIQClient.access_token");
var Art = context.getVariable("oauthv2accesstoken.Set-OAuth-v20-Info-NIQClient.refresh_token");

rpl.access_token = Aat;
rpl.refresh_token = Art;

context.setVariable('response.content', JSON.stringify(rpl));
context.setVariable('response.header.Pragma', "no-cache");
context.setVariable('response.header.Cache-Control', "no-store");
context.setVariable('response.header.Content-Length', JSON.stringify(rpl).length);

print("Parsing: \n" + rpl);

print ("Aat: \n" + Aat);
print ("Art: \n" + Art);
