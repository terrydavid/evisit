var apigeetoken = context.getVariable("apigee.access_token");
context.setVariable("niq.redirect_uri", "https://th-innovation-dev.apigee.net/nidp/redir?aat="+apigeetoken);