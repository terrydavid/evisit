var csecret = context.getVariable("request.queryparam.client_secret");

context.setVariable("request.queryparam.grant_type", "client_credentials");

if ( csecret === null || csecret === "" ) {
    context.setVariable("request.queryparam.client_secret", context.getVariable("verifyapikey.Verify-API-Key-1.client_secret"));
}