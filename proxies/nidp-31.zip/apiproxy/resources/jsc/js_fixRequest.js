 // move the token from the queryparam to the internal access_token field
var apigeetoken = context.getVariable("request.queryparam.aat");
context.setVariable("apigee.access_token", apigeetoken);

// Add the token value to the redirect uri 
context.setVariable("niq.redirect_uri", "https://th-innovation-dev.apigee.net/nidp/redir?aat="+apigeetoken);

// fixup the target path for tokens
context.setVariable("niq.targetpath", "/nidp/oauth/nam/token");

print ("access_token: " + apigeetoken + "\nredirect_uri: " + context.getVariable("niq.redirect_uri"));

