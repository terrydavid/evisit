var proxyHost = context.getVariable("request.header.Host");
context.setVariable("niq.proxyHost", proxyHost);

var grant_type = context.getVariable("request.queryparam.grant_type");
context.setVariable("niq.grant_type", grant_type);

var targetPath = context.getVariable("proxy.basepath") + context.getVariable("proxy.pathsuffix");
context.setVariable("niq.targetpath", targetPath);

var auth_code = context.getVariable("request.queryparam.code")
context.setVariable("niq.auth_code", auth_code);


print ("ProxyHost: " + proxyHost + "\nAuthCode: " + auth_code  + "\nGrantType: " + grant_type + "\nTargetPath: " + targetPath);