var lochdr = context.getVariable("response.header.Location");
var payload = context.getVariable("response.content");
var proxyHost = context.getVariable('niq.proxyHost');
var targethost = context.getVariable('niq.targethost');
// var target = context.getVariable('niq.target');
var target = context.getVariable('response.queryparam.target');

if ( proxyHost !== null ) {
    if ( lochdr !== null ) {
        lochdr = lochdr.replace('/'+targethost+'/g', proxyHost);
        context.setVariable("response.header.Location", lochdr);
    }
    if ( target !== null ) {
        target = target.replace('/'+targethost+'/g', proxyHost);
        context.setVariable("response.queryparam.target", target);
    }
    if ( payload !== null) {
        payload = payload.replace('/'+targethost+'/g', proxyHost);
        context.setVariable("response.content", payload);
    }
}

print ("LocHDR: " + context.getVariable("response.header.Location") + "\n targetHost: " + targethost + "\n proxyHost: " + proxyHost);
