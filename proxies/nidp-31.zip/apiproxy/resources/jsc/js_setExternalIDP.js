context.setVariable("oauth_external_authorization_status", "true");


//Debugging - remove when done

var nat = context.getVariable("niq.access_token");
var nrt = context.getVariable("niq.refresh_token");

print ("access_token: " + nat);
print ("refresh_token: " + nrt);