var content = context.getVariable("response.content");

if ( typeof content !== "undefined" && content !== null && content !== "" ) 
{
var body = JSON.parse(content);
var newbody = {};

newbody.access_token = body.access_token;
newbody.refresh_token = body.refresh_token;
newbody.token_type = body.token_type;

var nb = JSON.stringify(newbody); 
context.setVariable("response.content", nb);

}

print("Payload:\n" + nb);
