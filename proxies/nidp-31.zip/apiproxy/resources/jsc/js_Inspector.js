var content = context.getVariable('request.content');
var client_id = context.getVariable('request.queryparam.client_id');
var client_secret = context.getVariable('request.queryparam.client_secret');
var niqTargetHost = context.getVariable('niq.targethost');
print ("client: " + client_id + "\nsecret: " + client_secret + "\nTargetHost: " + niqTargetHost + "\ncontent: " + content);

// if (content !== null && content !== "") {
//     print ("client: \n" + client_id + ":" + client_secret);
    // var calloutObject = JSON.parse(servicecalloutcontent);
    // print ("myCalloutResponse: \n" + JSON.stringify(calloutObject));
//}

// var ratingsSourceObj = JSON.parse(servicecalloutcontent);
// var cleanRatings = {};
// cleanRatings = ratingsSourceObj.entities;

// for (var i = 0;i< cleanRatings.length; i++) {
//     delete(cleanRatings[i].uuid);
//     delete(cleanRatings[i].type);
//     delete(cleanRatings[i].created);
//     delete(cleanRatings[i].modified);
//     delete(cleanRatings[i].metadata);
//     // delete(cleanRatings[i].truck);
// }
// context.setVariable('ratingsResponse.content', JSON.stringify(cleanRatings));
// print ("myRatingsREaponse: \n" + JSON.stringify(cleanRatings));
