var Nat = context.getVariable("oauthv2accesstoken.OAuth-v20-chkToken.niqat");

context.setVariable("request.header.Authorization") = Nat;

print ("Nat: \n" + Nat);