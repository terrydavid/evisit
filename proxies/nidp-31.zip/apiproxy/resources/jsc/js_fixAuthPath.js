
var proxyPath = context.getVariable("proxy.pathsuffix");

context.setVariable("niq.targetpath", "/nidp/oauth/nam/token");

print ("targetpath: " + context.getVariable("niq.targetpath"));

