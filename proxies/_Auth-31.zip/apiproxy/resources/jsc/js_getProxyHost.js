var proxyHost = context.getVariable("request.header.Host");

context.setVariable("trans.proxy.Host", proxyHost);

print ("proxyHost: " + proxyHost);