var lochdr = context.getVariable("response.header.Location");
var proxyHost = context.getVariable('trans.proxy.Host');

lochdr = lochdr.replace("stagelogin.myid.care", proxyHost);

context.setVariable("response.header.Location", lochdr);

print ("LocHDR: " + context.getVariable("response.header.Location") + "\n proxyHost: " + proxyHost);

