var myTBP = context.getVariable("proxy.basepath");
context.setVariable("target.copy.pathsuffix", "false");