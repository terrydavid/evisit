var content = context.getVariable('request.content');
if (content !== null && content !== "") {
    print ("content: \n" + content);
    // var calloutObject = JSON.parse(servicecalloutcontent);
    // print ("myCalloutResponse: \n" + JSON.stringify(calloutObject));
}

// var ratingsSourceObj = JSON.parse(servicecalloutcontent);
// var cleanRatings = {};
// cleanRatings = ratingsSourceObj.entities;

// for (var i = 0;i< cleanRatings.length; i++) {
//     delete(cleanRatings[i].uuid);
//     delete(cleanRatings[i].type);
//     delete(cleanRatings[i].created);
//     delete(cleanRatings[i].modified);
//     delete(cleanRatings[i].metadata);
//     // delete(cleanRatings[i].truck);
// }
// context.setVariable('ratingsResponse.content', JSON.stringify(cleanRatings));
// print ("myRatingsREaponse: \n" + JSON.stringify(cleanRatings));
